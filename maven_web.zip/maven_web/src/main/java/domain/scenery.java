package domain;

public class scenery {
    private String scenery_id;
    private String scenery_name;
    private String city_id;
    private int start_count;
    private float scenery_score;
    private String scenery_avatar;
    private String scenery_detail;
    private String scenery_location;
    private String scenery_traffic;
    private String scenery_telephone;

    public String getScenery_id() {
        return scenery_id;
    }

    public void setScenery_id(String scenery_id) {
        this.scenery_id = scenery_id;
    }

    public String getScenery_name() {
        return scenery_name;
    }

    public void setScenery_name(String scenery_name) {
        this.scenery_name = scenery_name;
    }

    public String getCity_id() {
        return city_id;
    }

    public void setCity_id(String city_id) {
        this.city_id = city_id;
    }

    public int getStart_count() {
        return start_count;
    }

    public void setStart_count(int start_count) {
        this.start_count = start_count;
    }

    public float getScenery_score() {
        return scenery_score;
    }

    public void setScenery_score(float scenery_score) {
        this.scenery_score = scenery_score;
    }

    public String getScenery_avatar() {
        return scenery_avatar;
    }

    public void setScenery_avatar(String scenery_avatar) {
        this.scenery_avatar = scenery_avatar;
    }

    public String getScenery_detail() {
        return scenery_detail;
    }

    public void setScenery_detail(String scenery_detail) {
        this.scenery_detail = scenery_detail;
    }

    public String getScenery_location() {
        return scenery_location;
    }

    public void setScenery_location(String scenery_location) {
        this.scenery_location = scenery_location;
    }

    public String getScenery_traffic() {
        return scenery_traffic;
    }

    public void setScenery_traffic(String scenery_traffic) {
        this.scenery_traffic = scenery_traffic;
    }

    public String getScenery_telephone() {
        return scenery_telephone;
    }

    public void setScenery_telephone(String scenery_telephone) {
        this.scenery_telephone = scenery_telephone;
    }
}
