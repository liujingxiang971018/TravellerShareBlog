package servlet;

import domain.scenery_comment;
import domain.user;
import org.apache.commons.beanutils.BeanUtils;
import service.impl.routeServiceImpl;
import service.routeService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

/*保存评论*/
public class updateSceneryCommentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取参数
        //1.设置编码
        request.setCharacterEncoding("utf-8");
        //获取email
        HttpSession httpSession=request.getSession();
        String email = (String) httpSession.getAttribute("email");

        //2.获取map
        Map<String, Object[]> commentmap = request.getParameterMap();
        //3.封装对象
        scenery_comment comment=new scenery_comment();
        try {
            BeanUtils.populate(comment,commentmap);
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
        comment.setUser_id(email);

        //获取service
        routeService routeService=new routeServiceImpl();
        routeService.updateComment(comment);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
